WayangCMS
=========

![alt tag](http://www.wayang-cms.org/assets/img/hero-image.png)


Official Wayang CMS Repository on Github

The  development alpha version has been started, and will be launch about last January.

This our schedule for Wayang CMS Development

- Alpha1 Version Release
- Fixing Bugs
- Alpha2 Version Release with fixed bugs
- Fixing Bugs and Documentation
- Beta1 Version Release with Documentation
- Fixing Bugs
- Documentation Complete
- Stable Version Release



Alpha 1 Release
Feature lists:
- Pages
- Posts
- Categories
- Comments
- Users

Next Version with feature:
- Plugins
- Themes
- Dyanimc dashboard menu

Still stay with us

Best Regards

Wayang CMS Dev. Team
