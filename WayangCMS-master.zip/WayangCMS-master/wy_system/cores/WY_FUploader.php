<?php

/* 
 * Class for file uploader
 */
class WY_FUploader{
    
}