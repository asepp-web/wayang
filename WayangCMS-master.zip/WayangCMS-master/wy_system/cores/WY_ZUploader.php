<?php

/* 
 * Class for themes and plugin Uploader
 */
class WY_ZUploader{
    
    private function getInfo($file){
        
    }

    private function zipExtract(){
        
    }

    private function pluginUpload(){
        
    }

    private function themeUpload(){
        
    }

    public function upload(){
        
    }
}