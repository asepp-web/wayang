<?php

/**
 * Kelas ini berfungsi memuat form html
 * 
 */
class WY_Form
{
	public function open()
    {
        
    }
    
    public function close()
    {
        
    }
}