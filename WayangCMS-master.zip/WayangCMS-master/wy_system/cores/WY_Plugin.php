<?php

class WY_Plugin
{
	
}
