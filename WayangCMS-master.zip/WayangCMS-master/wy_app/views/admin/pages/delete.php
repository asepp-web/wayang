            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Pages -> Delete Pages</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>            
            <div class="row">
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Delete Pages -> {Title Page}
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Confirmation delete HERE -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
            </div>
            <!-- /.row -->