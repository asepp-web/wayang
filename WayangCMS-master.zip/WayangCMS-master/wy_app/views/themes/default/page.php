<div class="row col-lg-8">
    <div class="posting">
        <h2><a><?php echo $page->title; ?></a></h2>
        <?php echo $page->content; ?>
    </div>
</div> 