        <div class="media">
            <a class="pull-left" href="#">
                <img class="media-object ava" src="http://lorempixel.com/150/150/" alt="Generic placeholder image">
            </a>
            <div class="media-body">
                <h4 class="media-heading">Riko Ipsum</h4>
                <h4 class="media-meta"><i class="fa fa-clock-o"></i> 24 Jan 20:00</h4>
                <p>This is some sample text. This is some sample text. This is some sample text. This is some sample text. This is some sample text. This is some sample text. This is some sample text. This is some sample text.</p>
            </div>
        </div>