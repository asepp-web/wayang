<?php

class RegisterController extends WY_TController
{
	public $layout = 'layout';
    
    public function index()
    {
        
    }
}
