<?php

/**
 * Memuat kelas untuk autoload kelas lain
 * 
 */

require_once 'wy_system/cores/WY_Autoloader.php';

WY_Autoloader::register(); // register autoloader